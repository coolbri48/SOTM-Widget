import SwiftUI
import AppKit

struct SongData: Codable {
    var month: String
    var title: String
    var artist: String
    var playlistUrl: String
    var duration: String
    var cover: String?
}

struct EditorResult: Codable {
    var month: String
    var title: String
    var artist: String
    var playlistUrl: String
    var duration: String
    var coverSource: String
    var selectedFile: String
    var imageUrl: String
}

final class EditorState: ObservableObject {
    @Published var month: String
    @Published var title: String
    @Published var artist: String
    @Published var playlistUrl: String
    @Published var duration: String
    @Published var currentCoverPath: String

    @Published var coverSource = "keep"
    @Published var selectedFile = ""
    @Published var imageUrl = ""

    init(song: SongData) {
    month = song.month
    title = song.title
    artist = song.artist
    playlistUrl = song.playlistUrl
    duration = song.duration

    if let cover = song.cover, !cover.isEmpty {
        let executableURL = URL(
            fileURLWithPath: CommandLine.arguments[0]
        ).standardizedFileURL

        let widgetsFolder = executableURL
            .deletingLastPathComponent() // src
            .deletingLastPathComponent() // SOTM iPod Widget
            .deletingLastPathComponent() // widgets

        currentCoverPath = widgetsFolder
            .appendingPathComponent(cover)
            .path
    } else {
        currentCoverPath = ""
    }
}
}
struct ArtworkPreview: View {
    @ObservedObject var state: EditorState

    private var localPreviewPath: String {
        if state.coverSource == "file",
           !state.selectedFile.isEmpty {
            return state.selectedFile
        }

        return state.currentCoverPath
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 14)
                .fill(Color.secondary.opacity(0.08))

            if state.coverSource == "url",
               let url = URL(string: state.imageUrl),
               !state.imageUrl.isEmpty {

                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()

                    case .failure:
                        placeholder(
                            icon: "exclamationmark.triangle",
                            text: "Couldn’t load preview"
                        )

                    case .empty:
                        ProgressView()

                    @unknown default:
                        placeholder(
                            icon: "photo",
                            text: "No preview"
                        )
                    }
                }

            } else if let image = NSImage(
                contentsOfFile: localPreviewPath
            ) {
                Image(nsImage: image)
                    .resizable()
                    .scaledToFill()

            } else {
                placeholder(
                    icon: "music.note",
                    text: "No artwork"
                )
            }
        }
        .frame(width: 180, height: 180)
        .clipShape(
            RoundedRectangle(cornerRadius: 14)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 14)
                .stroke(
                    Color.secondary.opacity(0.18),
                    lineWidth: 1
                )
        }
    }

    @ViewBuilder
    private func placeholder(
        icon: String,
        text: String
    ) -> some View {
        VStack(spacing: 9) {
            Image(systemName: icon)
                .font(.system(size: 34))
                .foregroundStyle(.secondary)

            Text(text)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }
}

struct ContentView: View {
    @ObservedObject var state: EditorState
    let onCancel: () -> Void
    let onSave: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Edit Song of the Month")
                .font(.title2)
                .fontWeight(.semibold)

            Grid(alignment: .leading, horizontalSpacing: 18, verticalSpacing: 12) {
                GridRow {
                    Text("Month")
                    TextField("", text: $state.month)
                        .textFieldStyle(.roundedBorder)
                }

                GridRow {
                    Text("Song title")
                    TextField("", text: $state.title)
                        .textFieldStyle(.roundedBorder)
                }

                GridRow {
                    Text("Artist")
                    TextField("", text: $state.artist)
                        .textFieldStyle(.roundedBorder)
                }

                GridRow {
                    Text("Spotify playlist")
                    TextField("", text: $state.playlistUrl)
                        .textFieldStyle(.roundedBorder)
                }

                GridRow {
                    Text("Duration")
                    TextField("", text: $state.duration)
                        .textFieldStyle(.roundedBorder)
                        .frame(width: 120)
                }
            }

            Divider()

HStack(alignment: .top, spacing: 26) {
    ArtworkPreview(state: state)

    VStack(alignment: .leading, spacing: 13) {
        Text("Album artwork")
            .font(.headline)

        Picker("", selection: $state.coverSource) {
            Text("Keep current artwork")
                .tag("keep")

            Text("Choose image file")
                .tag("file")

            Text("Paste image URL")
                .tag("url")
        }
        .labelsHidden()
        .pickerStyle(.radioGroup)

        if state.coverSource == "file" {
            HStack {
                Button("Choose Image…") {
                    let panel = NSOpenPanel()

                    panel.allowedContentTypes = [
                        .jpeg,
                        .png,
                        .webP
                    ]

                    panel.allowsMultipleSelection = false
                    panel.canChooseDirectories = false

                    if panel.runModal() == .OK,
                       let url = panel.url {
                        state.selectedFile = url.path
                    }
                }

                Text(
                    state.selectedFile.isEmpty
                        ? "No file selected"
                        : URL(
                            fileURLWithPath:
                                state.selectedFile
                        ).lastPathComponent
                )
                .foregroundStyle(.secondary)
                .lineLimit(1)
            }
        }

        if state.coverSource == "url" {
            TextField(
                "https://example.com/cover.jpg",
                text: $state.imageUrl
            )
            .textFieldStyle(.roundedBorder)
            .frame(width: 330)
        }

        Text("The widget stores its own copy of new artwork.")
            .font(.caption)
            .foregroundStyle(.secondary)
    }

    Spacer()
}

            HStack {
                Spacer()

                Button("Cancel") {
                    onCancel()
                }
                .keyboardShortcut(.cancelAction)

                Button("Save Changes") {
                    onSave()
                }
                .keyboardShortcut(.defaultAction)
                .disabled(
                    state.month.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                    state.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                    state.artist.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                    state.playlistUrl.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                    state.duration.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                    (state.coverSource == "file" && state.selectedFile.isEmpty) ||
                    (state.coverSource == "url" && state.imageUrl.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                )
            }
        }
        .padding(24)
        .frame(width: 620, height: 520)
    }
}

final class AppController: NSObject, NSApplicationDelegate {
    private var window: NSWindow?
    private var state: EditorState?

    private func installMainMenu() {
    let mainMenu = NSMenu()

    let appMenuItem = NSMenuItem()
    mainMenu.addItem(appMenuItem)

    let appMenu = NSMenu()
    appMenuItem.submenu = appMenu

    appMenu.addItem(
        withTitle: "Quit SongEditor",
        action: #selector(NSApplication.terminate(_:)),
        keyEquivalent: "q"
    )

    let editMenuItem = NSMenuItem()
    mainMenu.addItem(editMenuItem)

    let editMenu = NSMenu(title: "Edit")
    editMenuItem.submenu = editMenu

    editMenu.addItem(
        withTitle: "Undo",
        action: Selector(("undo:")),
        keyEquivalent: "z"
    )

    editMenu.addItem(
        withTitle: "Redo",
        action: Selector(("redo:")),
        keyEquivalent: "Z"
    )

    editMenu.addItem(.separator())

    editMenu.addItem(
        withTitle: "Cut",
        action: #selector(NSText.cut(_:)),
        keyEquivalent: "x"
    )

    editMenu.addItem(
        withTitle: "Copy",
        action: #selector(NSText.copy(_:)),
        keyEquivalent: "c"
    )

    editMenu.addItem(
        withTitle: "Paste",
        action: #selector(NSText.paste(_:)),
        keyEquivalent: "v"
    )

    editMenu.addItem(
        withTitle: "Select All",
        action: #selector(NSText.selectAll(_:)),
        keyEquivalent: "a"
    )

    NSApplication.shared.mainMenu = mainMenu
}

    func applicationDidFinishLaunching(_ notification: Notification) {
        installMainMenu()
        
        do {
            let inputData = FileHandle.standardInput.readDataToEndOfFile()
            
            guard !inputData.isEmpty else {
                fputs("No song data was provided.\n", stderr)
                NSApplication.shared.terminate(nil)
                return
            }

            let song = try JSONDecoder().decode(SongData.self, from: inputData)
            let editorState = EditorState(song: song)
            self.state = editorState

            let contentView = ContentView(
                state: editorState,
                onCancel: {
                    exit(2)
                },
                onSave: {
                    self.saveAndExit()
                }
            )

            let hostingView = NSHostingView(rootView: contentView)

            let window = NSWindow(
                contentRect: NSRect(x: 0, y: 0, width: 620, height: 470),
                styleMask: [
                    .titled,
                    .closable,
                    .miniaturizable
                ],
                backing: .buffered,
                defer: false
            )

            window.title = "Edit Song of the Month"
            window.contentView = hostingView
            window.center()
            window.makeKeyAndOrderFront(nil)

            NSApplication.shared.activate(
                ignoringOtherApps: true
            )

            self.window = window
        } catch {
            fputs("Could not open editor: \(error)\n", stderr)
            NSApplication.shared.terminate(nil)
        }
    }

    private func saveAndExit() {
        guard let state else {
            exit(1)
        }

        let result = EditorResult(
            month: state.month.trimmingCharacters(in: .whitespacesAndNewlines),
            title: state.title.trimmingCharacters(in: .whitespacesAndNewlines),
            artist: state.artist.trimmingCharacters(in: .whitespacesAndNewlines),
            playlistUrl: state.playlistUrl.trimmingCharacters(in: .whitespacesAndNewlines),
            duration: state.duration.trimmingCharacters(in: .whitespacesAndNewlines),
            coverSource: state.coverSource,
            selectedFile: state.selectedFile,
            imageUrl: state.imageUrl.trimmingCharacters(in: .whitespacesAndNewlines)
        )

        do {
            let outputData = try JSONEncoder().encode(result)
            FileHandle.standardOutput.write(outputData)
            FileHandle.standardOutput.write(
                Data("\n".utf8)
            )
            exit(0)
        } catch {
            fputs("Could not save edits: \(error)\n", stderr)
            exit(1)
        }
    }

    func applicationShouldTerminateAfterLastWindowClosed(
        _ sender: NSApplication
    ) -> Bool {
        true
    }
}

let app = NSApplication.shared
let delegate = AppController()

app.setActivationPolicy(.regular)
app.delegate = delegate
app.run()