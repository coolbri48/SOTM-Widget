export default {
  "x": 361,
  "y": 19,
  "scale": 0.55
};
