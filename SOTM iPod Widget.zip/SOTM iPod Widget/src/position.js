export default {
  "x": 362,
  "y": 21,
  "scale": 0.55
};
