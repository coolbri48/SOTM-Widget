export default {
  "x": 362,
  "y": 22,
  "scale": 0.55
};
