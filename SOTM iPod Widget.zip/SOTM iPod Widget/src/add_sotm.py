#!/usr/bin/env python3

import json
import random
import re
import shutil
import subprocess
import sys
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urlparse


WIDGET_DIR = Path(__file__).resolve().parent.parent
SONGS_FILE = WIDGET_DIR / "src" / "songs.js"
COVERS_DIR = WIDGET_DIR / "album covers"


def dialog(prompt: str, default: str = ""):
    """Show a macOS text-entry dialog."""
    safe_prompt = prompt.replace("\\", "\\\\").replace('"', '\\"')
    safe_default = default.replace("\\", "\\\\").replace('"', '\\"')

    script = f'''
    tell application "System Events"
        activate
        try
            set response to display dialog "{safe_prompt}" ¬
                default answer "{safe_default}" ¬
                buttons {{"Cancel", "Continue"}} ¬
                default button "Continue" ¬
                cancel button "Cancel"

            return text returned of response
        on error number -128
            return "__CANCELLED__"
        end try
    end tell
    '''

    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True,
        text=True
    )

    value = result.stdout.strip()

    if value == "__CANCELLED__" or not value:
        return None

    return value


def alert(message: str):
    """Show a macOS alert."""
    safe_message = message.replace("\\", "\\\\").replace('"', '\\"')

    subprocess.run([
        "osascript",
        "-e",
        f'display alert "{safe_message}"'
    ])


def ask_required(prompt: str, default: str = ""):
    """Keep asking until the user enters something or cancels."""
    while True:
        answer = dialog(prompt, default)

        if answer is None:
            return None

        answer = answer.strip()

        if answer:
            return answer

        alert("That field cannot be empty.")


def choose_cover_source():
    """Ask whether to use a local image or an image URL."""
    script = '''
    tell application "System Events"
        activate
        try
            set response to display dialog "How would you like to add the album artwork?" ¬
                with title "Song of the Month" ¬
                buttons {"Cancel", "Paste Image URL", "Choose Image File"} ¬
                default button "Choose Image File" ¬
                cancel button "Cancel"

            return button returned of response
        on error number -128
            return "__CANCELLED__"
        end try
    end tell
    '''

    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True,
        text=True
    )

    choice = result.stdout.strip()

    if choice == "__CANCELLED__" or not choice:
        return None

    return choice


def choose_image_file():
    """Open Finder so the user can choose an image."""
    script = '''
    tell application "System Events"
        activate
        try
            set selectedFile to choose file with prompt "Choose album artwork:"
            return POSIX path of selectedFile
        on error number -128
            return "__CANCELLED__"
        end try
    end tell
    '''

    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True,
        text=True
    )

    value = result.stdout.strip()

    if value == "__CANCELLED__" or not value:
        return None

    return Path(value)


def safe_filename(text):
    """Convert text into a safe filename."""
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "_", text.strip())
    return cleaned.strip("_") or "cover"


def unique_cover_path(base_name, extension):
    """Create a cover filename without overwriting another image."""
    extension = extension.lower()

    if extension not in {".jpg", ".jpeg", ".png", ".webp"}:
        extension = ".jpg"

    candidate = COVERS_DIR / f"{base_name}{extension}"
    counter = 2

    while candidate.exists():
        candidate = COVERS_DIR / f"{base_name}_{counter}{extension}"
        counter += 1

    return candidate


def copy_local_cover(source_path, month, title):
    """Copy a selected image into the widget folder."""
    if not source_path.exists():
        raise FileNotFoundError("The selected image could not be found.")

    extension = source_path.suffix.lower() or ".jpg"

    if extension not in {".jpg", ".jpeg", ".png", ".webp"}:
        raise ValueError(
            "Please choose a JPG, JPEG, PNG, or WEBP image."
        )

    base_name = safe_filename(f"{month}_{title}")
    destination = unique_cover_path(base_name, extension)

    shutil.copy2(source_path, destination)

    return destination.name


def download_cover(url, month, title):
    """Download an online image into the widget folder."""
    if not url.startswith(("http://", "https://")):
        raise ValueError(
            "The image URL must begin with http:// or https://"
        )

    parsed = urlparse(url)
    extension = Path(parsed.path).suffix.lower()

    if extension not in {".jpg", ".jpeg", ".png", ".webp"}:
        extension = ".jpg"

    base_name = safe_filename(f"{month}_{title}")
    destination = unique_cover_path(base_name, extension)

    request = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0"}
    )

    with urllib.request.urlopen(request, timeout=20) as response:
        image_data = response.read()

    if not image_data:
        raise ValueError("No image data was downloaded from that URL.")

    destination.write_bytes(image_data)

    return destination.name


def time_to_seconds(time_text):
    """Convert M:SS or H:MM:SS into seconds."""
    parts = time_text.strip().split(":")

    try:
        numbers = [int(part) for part in parts]
    except ValueError:
        raise ValueError(
            "Duration must look like 3:42 or 1:03:15."
        )

    if len(numbers) == 2:
        minutes, seconds = numbers

        if minutes < 0 or seconds < 0 or seconds >= 60:
            raise ValueError("Duration must look like 3:42.")

        return minutes * 60 + seconds

    if len(numbers) == 3:
        hours, minutes, seconds = numbers

        if (
            hours < 0
            or minutes < 0
            or minutes >= 60
            or seconds < 0
            or seconds >= 60
        ):
            raise ValueError(
                "Duration must look like 1:03:15."
            )

        return hours * 3600 + minutes * 60 + seconds

    raise ValueError(
        "Duration must look like 3:42 or 1:03:15."
    )


def seconds_to_time(total_seconds):
    """Convert seconds into M:SS or H:MM:SS."""
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)

    if hours:
        return f"{hours}:{minutes:02d}:{seconds:02d}"

    return f"{minutes}:{seconds:02d}"


def load_songs():
    """Read the song list from songs.js."""
    if not SONGS_FILE.exists():
        raise FileNotFoundError(
            f"Could not find songs.js at:\\n{SONGS_FILE}"
        )

    contents = SONGS_FILE.read_text(encoding="utf-8")

    match = re.search(
        r"export\s+default\s+(\[.*\])\s*;?\s*$",
        contents,
        re.DOTALL
    )

    if not match:
        raise ValueError(
            "songs.js must use the format: export default [...];"
        )

    return json.loads(match.group(1))


def save_songs(songs):
    """Save the song list back into songs.js."""
    formatted = json.dumps(
        songs,
        indent=2,
        ensure_ascii=False
    )

    SONGS_FILE.write_text(
        f"export default {formatted};\n",
        encoding="utf-8"
    )

def suggested_sotm_month():
    """Return the month and year from 10 days ago."""
    target_date = datetime.now() - timedelta(days=10)
    return target_date.strftime("%B %Y")

def main():
    try:
        COVERS_DIR.mkdir(parents=True, exist_ok=True)

        month = ask_required(
         "Month and year:",
         suggested_sotm_month()
        )

        if month is None:
            return 0

        title = ask_required("Song title:")
        if title is None:
            return 0

        artist = ask_required("Artist:")
        if artist is None:
            return 0

        cover_source = choose_cover_source()

        if cover_source is None:
            return 0

        if cover_source == "Choose Image File":
            selected_file = choose_image_file()

            if selected_file is None:
                return 0

            cover_filename = copy_local_cover(
                selected_file,
                month,
                title
            )

        elif cover_source == "Paste Image URL":
            image_url = ask_required(
                "Paste a direct image URL:",
                "https://"
            )

            if image_url is None:
                return 0

            cover_filename = download_cover(
                image_url,
                month,
                title
            )

        else:
            raise ValueError(
                "An album-art source was not selected."
            )

        playlist_url = ask_required(
            "Spotify link for this month's playlist:"
        )
        if playlist_url is None:
            return 0

        duration = ask_required(
            "Song duration, formatted like 3:42:",
            "3:00"
        )
        if duration is None:
            return 0

        total_seconds = time_to_seconds(duration)

        if total_seconds < 10:
            raise ValueError(
                "The song duration must be at least 10 seconds."
            )

        # Choose one fixed point between 15% and 85% of the song.
        minimum_second = max(
            1,
            round(total_seconds * 0.15)
        )

        maximum_second = min(
            total_seconds - 1,
            round(total_seconds * 0.85)
        )

        random_second = random.randint(
            minimum_second,
            maximum_second
        )

        current_time = seconds_to_time(random_second)

        progress = round(
            (random_second / total_seconds) * 100
        )

        songs = load_songs()

        # This automatically uses the current widget folder's name.
        cover_widget_path = (
            f"{WIDGET_DIR.name}/album covers/{cover_filename}"
        )

        songs.append({
            "month": month,
            "title": title,
            "artist": artist,
            "cover": cover_widget_path,
            "playlistUrl": playlist_url,
            "currentTime": current_time,
            "duration": duration,
            "progress": progress
        })

        save_songs(songs)

        alert(
            f"{title} by {artist} was added for {month}. "
            "Übersicht should update automatically."
        )

        return 0

    except Exception as error:
        alert(f"Could not add the song:\\n{error}")
        return 1


if __name__ == "__main__":
    sys.exit(main())