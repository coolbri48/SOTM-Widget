##!/usr/bin/env python3

import json
import sys
from pathlib import Path


POSITION_FILE = Path(__file__).resolve().parent / "position.js"


def main():
    if len(sys.argv) != 4:
        return 1

    try:
        x = round(float(sys.argv[1]))
        y = round(float(sys.argv[2]))
        scale = round(float(sys.argv[3]), 3)
    except ValueError:
        return 1

    x = max(0, x)
    y = max(0, y)

    # Prevent absurdly tiny or huge sizing.
    scale = max(0.25, min(1.4, scale))

    settings = {
        "x": x,
        "y": y,
        "scale": scale
    }

    POSITION_FILE.write_text(
        "export default "
        + json.dumps(settings, indent=2)
        + ";\n",
        encoding="utf-8"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())