#!/usr/bin/env python3

import json
import random
import re
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path
from urllib.parse import urlparse


WIDGET_DIR = Path(__file__).resolve().parent.parent
SONGS_FILE = WIDGET_DIR / "src" / "songs.js"
COVERS_DIR = WIDGET_DIR / "album covers"


def alert(message):
    safe_message = message.replace("\\", "\\\\").replace('"', '\\"')

    subprocess.run([
        "osascript",
        "-e",
        f'display alert "{safe_message}"'
    ])


def dialog(prompt, default=""):
    safe_prompt = prompt.replace("\\", "\\\\").replace('"', '\\"')
    safe_default = default.replace("\\", "\\\\").replace('"', '\\"')

    script = f'''
    tell application "System Events"
        activate
        try
            set response to display dialog "{safe_prompt}" ¬
                default answer "{safe_default}" ¬
                buttons {{"Cancel", "Continue"}} ¬
                default button "Continue" ¬
                cancel button "Cancel"

            return text returned of response
        on error number -128
            return "__CANCELLED__"
        end try
    end tell
    '''

    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True,
        text=True
    )

    value = result.stdout.strip()

    if value == "__CANCELLED__":
        return None

    return value


def ask_required(prompt, default=""):
    while True:
        answer = dialog(prompt, default)

        if answer is None:
            return None

        answer = answer.strip()

        if answer:
            return answer

        alert("That field cannot be empty.")

def choose_manage_action(song):
    month = song.get("month", "Unknown Month")
    title = song.get("title", "Untitled")
    artist = song.get("artist", "Unknown Artist")

    message = (
        f"Make changes to:\n\n"
        f"{month}: {title} — {artist}"
    )

    safe_message = (
        message
        .replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\n", "\\n")
    )

    script = f'''
    tell application "System Events"
        activate
        try
            set response to display dialog "{safe_message}" ¬
                with title "Manage Song of the Month" ¬
                buttons {{"Cancel", "Delete Entry", "Edit Entry"}} ¬
                default button "Edit Entry" ¬
                cancel button "Cancel"

            return button returned of response
        on error number -128
            return "__CANCELLED__"
        end try
    end tell
    '''

    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True,
        text=True
    )

    choice = result.stdout.strip()

    if choice == "__CANCELLED__" or not choice:
        return None

    return choice

def confirm_delete(song):
    title = song.get("title", "Untitled")
    month = song.get("month", "Unknown Month")

    safe_text = (
        f'Delete "{title}" for {month}?\\n\\n'
        "This cannot be undone."
    ).replace("\\", "\\\\").replace('"', '\\"')

    script = f'''
    tell application "System Events"
        activate
        try
            set response to display dialog "{safe_text}" ¬
                with title "Delete Song of the Month" ¬
                buttons {{"Cancel", "Delete"}} ¬
                default button "Cancel" ¬
                cancel button "Cancel" ¬
                with icon caution

            return button returned of response
        on error number -128
            return "__CANCELLED__"
        end try
    end tell
    '''

    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True,
        text=True
    )

    return result.stdout.strip() == "Delete"


def choose_cover_action():
    script = '''
    tell application "System Events"
        activate
        try
            set response to display dialog "Album artwork" ¬
                with title "Edit Song of the Month" ¬
                buttons {"Keep Current", "Paste New URL", "Choose New File"} ¬
                default button "Keep Current"

            return button returned of response
        on error number -128
            return "__CANCELLED__"
        end try
    end tell
    '''

    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True,
        text=True
    )

    value = result.stdout.strip()

    if value == "__CANCELLED__" or not value:
        return None

    return value


def choose_image_file():
    script = '''
    tell application "System Events"
        activate
        try
            set selectedFile to choose file with prompt "Choose album artwork:"
            return POSIX path of selectedFile
        on error number -128
            return "__CANCELLED__"
        end try
    end tell
    '''

    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True,
        text=True
    )

    value = result.stdout.strip()

    if value == "__CANCELLED__" or not value:
        return None

    return Path(value)


def safe_filename(text):
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "_", text.strip())
    return cleaned.strip("_") or "cover"


def unique_cover_path(base_name, extension):
    extension = extension.lower()

    if extension not in {".jpg", ".jpeg", ".png", ".webp"}:
        extension = ".jpg"

    candidate = COVERS_DIR / f"{base_name}{extension}"
    counter = 2

    while candidate.exists():
        candidate = COVERS_DIR / f"{base_name}_{counter}{extension}"
        counter += 1

    return candidate


def copy_local_cover(source_path, month, title):
    if not source_path.exists():
        raise FileNotFoundError("The selected image could not be found.")

    extension = source_path.suffix.lower()

    if extension not in {".jpg", ".jpeg", ".png", ".webp"}:
        raise ValueError("Please choose a JPG, JPEG, PNG, or WEBP image.")

    destination = unique_cover_path(
        safe_filename(f"{month}_{title}"),
        extension
    )

    shutil.copy2(source_path, destination)

    return destination.name


def download_cover(url, month, title):
    if not url.startswith(("http://", "https://")):
        raise ValueError(
            "The image URL must begin with http:// or https://"
        )

    parsed = urlparse(url)
    extension = Path(parsed.path).suffix.lower()

    if extension not in {".jpg", ".jpeg", ".png", ".webp"}:
        extension = ".jpg"

    destination = unique_cover_path(
        safe_filename(f"{month}_{title}"),
        extension
    )

    request = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0"}
    )

    with urllib.request.urlopen(request, timeout=20) as response:
        image_data = response.read()

    if not image_data:
        raise ValueError("No image data was downloaded.")

    destination.write_bytes(image_data)

    return destination.name


def time_to_seconds(time_text):
    parts = time_text.strip().split(":")

    try:
        numbers = [int(part) for part in parts]
    except ValueError:
        raise ValueError("Duration must look like 3:42.")

    if len(numbers) != 2:
        raise ValueError("Duration must look like 3:42.")

    minutes, seconds = numbers

    if minutes < 0 or seconds < 0 or seconds >= 60:
        raise ValueError("Duration must look like 3:42.")

    return minutes * 60 + seconds


def seconds_to_time(total_seconds):
    minutes, seconds = divmod(total_seconds, 60)
    return f"{minutes}:{seconds:02d}"


def make_progress(duration):
    total_seconds = time_to_seconds(duration)

    if total_seconds < 10:
        raise ValueError(
            "The song duration must be at least 10 seconds."
        )

    minimum_second = max(
        1,
        round(total_seconds * 0.15)
    )

    maximum_second = min(
        total_seconds - 1,
        round(total_seconds * 0.85)
    )

    random_second = random.randint(
        minimum_second,
        maximum_second
    )

    current_time = seconds_to_time(random_second)
    progress = round((random_second / total_seconds) * 100)

    return current_time, progress


def load_songs():
    contents = SONGS_FILE.read_text(encoding="utf-8")

    match = re.search(
        r"export\s+default\s+(\[.*\])\s*;?\s*$",
        contents,
        re.DOTALL
    )

    if not match:
        raise ValueError(
            "songs.js must use: export default [...];"
        )

    return json.loads(match.group(1))


def save_songs(songs):
    formatted = json.dumps(
        songs,
        indent=2,
        ensure_ascii=False
    )

    SONGS_FILE.write_text(
        f"export default {formatted};\n",
        encoding="utf-8"
    )


def stored_cover_file(cover_path):
    if not cover_path:
        return None

    return WIDGET_DIR.parent / cover_path


def remove_unused_cover(deleted_cover, remaining_songs):
    if not deleted_cover:
        return

    still_used = any(
        song.get("cover") == deleted_cover
        for song in remaining_songs
    )

    if still_used:
        return

    cover_file = stored_cover_file(deleted_cover)

    if (
        cover_file
        and cover_file.exists()
        and COVERS_DIR in cover_file.parents
    ):
        cover_file.unlink()


def delete_song(songs, index):
    song = songs[index]

    if not confirm_delete(song):
        return

    deleted_cover = song.get("cover")

    del songs[index]

    save_songs(songs)
    remove_unused_cover(deleted_cover, songs)

    alert(
        f'{song.get("title", "Song")} was deleted.'
    )

def show_edit_window(song):
    """Open the native SwiftUI editor and return its edited values."""
    editor_path = WIDGET_DIR / "src" / "SongEditor"

    if not editor_path.exists():
        raise FileNotFoundError(
            f"Could not find the native editor at:\n{editor_path}"
        )

    input_data = json.dumps(song)

    result = subprocess.run(
        [str(editor_path)],
        input=input_data,
        capture_output=True,
        text=True
    )

    if result.returncode == 2:
        return None

    if result.returncode != 0:
        error_text = result.stderr.strip() or "Unknown editor error."
        raise RuntimeError(error_text)

    output = result.stdout.strip()

    if not output:
        return None

    return json.loads(output)

    def choose_file():
        path = filedialog.askopenfilename(
            title="Choose album artwork",
            filetypes=[
                (
                    "Image files",
                    "*.jpg *.jpeg *.png *.webp"
                )
            ]
        )

        if path:
            selected_file["path"] = path
            cover_choice.set("file")
            file_label.config(
                text=Path(path).name
            )

    tk.Button(
        cover_frame,
        text="Browse…",
        command=choose_file
    ).pack(anchor="w", padx=(24, 0), pady=(3, 5))

    url_frame = tk.Frame(cover_frame)
    url_frame.pack(anchor="w")

    tk.Radiobutton(
        url_frame,
        text="Paste image URL",
        variable=cover_choice,
        value="url"
    ).pack(side="left")

    image_url_entry = tk.Entry(
        url_frame,
        width=30
    )
    image_url_entry.pack(
        side="left",
        padx=(8, 0)
    )

    def select_url(_event=None):
        cover_choice.set("url")

    image_url_entry.bind(
        "<FocusIn>",
        select_url
    )

    button_row = tk.Frame(container)
    button_row.grid(
        row=cover_row + 1,
        column=0,
        columnspan=2,
        sticky="e",
        pady=(18, 0)
    )

    def cancel():
        root.destroy()

    def save():
        nonlocal result

        values = {
            key: entry.get().strip()
            for key, entry in fields.items()
        }

        required = [
            "month",
            "title",
            "artist",
            "playlistUrl",
            "duration"
        ]

        if any(not values[key] for key in required):
            messagebox.showerror(
                "Missing information",
                "Please complete every field."
            )
            return

        source = cover_choice.get()

        if source == "file" and not selected_file["path"]:
            messagebox.showerror(
                "No image selected",
                "Choose an image file first."
            )
            return

        image_url = image_url_entry.get().strip()

        if source == "url" and not image_url:
            messagebox.showerror(
                "No image URL",
                "Paste an image URL first."
            )
            return

        result = {
            **values,
            "coverSource": source,
            "selectedFile": selected_file["path"],
            "imageUrl": image_url
        }

        root.destroy()

    tk.Button(
        button_row,
        text="Cancel",
        width=10,
        command=cancel
    ).pack(side="left", padx=(0, 8))

    tk.Button(
        button_row,
        text="Save Changes",
        width=14,
        command=save
    ).pack(side="left")

    root.protocol("WM_DELETE_WINDOW", cancel)
    root.mainloop()

    return result

def edit_song(songs, index):
    song = songs[index]

    original_duration = song.get(
        "duration",
        "3:00"
    )
    original_cover = song.get(
        "cover",
        ""
    )

    edited = show_edit_window(song)

    if edited is None:
        return

    month = edited["month"]
    title = edited["title"]
    artist = edited["artist"]
    playlist_url = edited["playlistUrl"]
    duration = edited["duration"]

    new_cover = original_cover
    cover_source = edited["coverSource"]

    if cover_source == "file":
        selected_file = Path(
            edited["selectedFile"]
        )

        filename = copy_local_cover(
            selected_file,
            month,
            title
        )

        new_cover = (
            f"{WIDGET_DIR.name}/album covers/{filename}"
        )

    elif cover_source == "url":
        filename = download_cover(
            edited["imageUrl"],
            month,
            title
        )

        new_cover = (
            f"{WIDGET_DIR.name}/album covers/{filename}"
        )

    current_time = song.get(
        "currentTime",
        "0:00"
    )
    progress = song.get(
        "progress",
        0
    )

    if duration != original_duration:
        current_time, progress = make_progress(
            duration
        )

    songs[index] = {
        "month": month,
        "title": title,
        "artist": artist,
        "cover": new_cover,
        "playlistUrl": playlist_url,
        "currentTime": current_time,
        "duration": duration,
        "progress": progress
    }

    save_songs(songs)

    if new_cover != original_cover:
        remove_unused_cover(
            original_cover,
            songs
        )

    alert(
        f"{title} was updated successfully."
    )


def main():
    try:
        if len(sys.argv) < 2:
            raise ValueError(
                "No song index was supplied."
            )

        index = int(sys.argv[1])
        songs = load_songs()

        if not songs:
            alert("There are no songs to manage.")
            return 0

        if index < 0 or index >= len(songs):
            index = len(songs) - 1

        action = choose_manage_action(songs[index])

        if action == "Edit Entry":
            edit_song(songs, index)

        elif action == "Delete Entry":
            delete_song(songs, index)

        return 0

    except Exception as error:
        alert(f"Could not manage the song:\\n{error}")
        return 1


if __name__ == "__main__":
    sys.exit(main())