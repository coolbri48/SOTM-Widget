hi this is my SOTM widget 

to install:
1. install Übersicht (https://tracesof.net/uebersicht/)
2. unzip this download
3. move the folder into ~/Library/Application Support/Übersicht/widgets/
4. open übersicht and enable the widget

controls:
- drag the iPod to move it
- drag the bottom right corner to resize
- ▶Ⅱ will add a new song
- MENU will open the displayed month spotify playlist (if you put a link to it)
- ◀ and ▶ go between months
- the center button will let you edit or delete the displayed month entry

for album cover:

- when you add or edit an entry you can either choose an image file on your Mac or paste a direct link (find the image on browser, right click, pick copy image address, paste that)
- the widget will make its own copy so the original image if downloaded on computer can be deleted

notes:
- dont rename the "SOTM iPod Widget" or else it will break :(
- spotify has to be downloaded for playlists to open directly in the app