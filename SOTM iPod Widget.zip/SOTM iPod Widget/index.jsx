import { run } from "uebersicht";
import songsData from "./src/songs";
import savedPosition from "./src/position";
export const refreshFrequency = false;

const songs = songsData;

export const initialState = {
  selectedIndex: songs.length - 1,
  positionX: savedPosition.x,
  positionY: savedPosition.y,
  widgetScale:
  savedPosition.scale !== undefined
    ? savedPosition.scale
    : 0.55
};

export const updateState = (event, previousState) => {
  if (event.type === "SET_SCALE") {
  return {
    ...previousState,
    widgetScale: event.scale
  };
}
  if (event.type === "PREVIOUS_MONTH") {
    return {
      ...previousState,
      selectedIndex:
        previousState.selectedIndex === 0
          ? songs.length - 1
          : previousState.selectedIndex - 1
    };
  }

  if (event.type === "NEXT_MONTH") {
    return {
      ...previousState,
      selectedIndex:
        previousState.selectedIndex === songs.length - 1
          ? 0
          : previousState.selectedIndex + 1
    };
  }

  if (event.type === "SET_POSITION") {
    return {
      ...previousState,
      positionX: event.x,
      positionY: event.y
    };
  }

  return previousState;
};

const openUrl = (url) => {
  if (!url) return;

  let spotifyUri = null;

  if (url.includes("open.spotify.com/playlist/")) {
    const id = url.split("/playlist/")[1].split("?")[0];
    spotifyUri = `spotify:playlist:${id}`;
  } else if (url.includes("open.spotify.com/track/")) {
    const id = url.split("/track/")[1].split("?")[0];
    spotifyUri = `spotify:track:${id}`;
  } else if (url.includes("open.spotify.com/album/")) {
    const id = url.split("/album/")[1].split("?")[0];
    spotifyUri = `spotify:album:${id}`;
  } else if (url.startsWith("spotify:")) {
    spotifyUri = url;
  }

  const safeWebUrl = url.replace(/'/g, "'\\''");

  if (spotifyUri) {
    const safeSpotifyUri = spotifyUri.replace(/'/g, "'\\''");

    run(
      `if open -Ra "Spotify"; then ` +
      `open -a "Spotify" '${safeSpotifyUri}'; ` +
      `else open '${safeWebUrl}'; fi`
    );

    return;
  }

  run(`open '${safeWebUrl}'`);
};

let activeDrag = null;
let activeResize = null;

const saveWidgetSettings = (x, y, scale) => {
  run(
    `/usr/bin/python3 ` +
    `"$HOME/Library/Application Support/Übersicht/widgets/SOTM iPod Widget/src/save_position.py" ` +
    `${Math.round(x)} ${Math.round(y)} ${scale}`
  );
};

const beginWidgetDrag = (
  mouseDownEvent,
  positionX,
  positionY,
  currentScale,
  dispatch
) => {
  if (
    mouseDownEvent.target.closest("button") ||
    mouseDownEvent.target.closest("a") ||
    mouseDownEvent.target.closest(".resize-handle") ||
    mouseDownEvent.button !== 0
  ) {
    return;
  }

  mouseDownEvent.preventDefault();

  activeDrag = {
    startMouseX: mouseDownEvent.clientX,
    startMouseY: mouseDownEvent.clientY,
    startPositionX: positionX,
    startPositionY: positionY
  };

  const moveWidget = (moveEvent) => {
    if (!activeDrag) return;

    const nextX =
      activeDrag.startPositionX +
      (moveEvent.clientX - activeDrag.startMouseX);

    const nextY =
      activeDrag.startPositionY +
      (moveEvent.clientY - activeDrag.startMouseY);

    dispatch({
      type: "SET_POSITION",
      x: Math.max(0, nextX),
      y: Math.max(0, nextY)
    });
  };

  const finishWidgetDrag = (upEvent) => {
    if (!activeDrag) return;

    const finalX = Math.max(
      0,
      activeDrag.startPositionX +
        (upEvent.clientX - activeDrag.startMouseX)
    );

    const finalY = Math.max(
      0,
      activeDrag.startPositionY +
        (upEvent.clientY - activeDrag.startMouseY)
    );

    dispatch({
      type: "SET_POSITION",
      x: finalX,
      y: finalY
    });

    saveWidgetSettings(
      finalX,
      finalY,
      currentScale
    );

    activeDrag = null;

    document.removeEventListener(
      "mousemove",
      moveWidget
    );

    document.removeEventListener(
      "mouseup",
      finishWidgetDrag
    );
  };

  document.addEventListener(
    "mousemove",
    moveWidget
  );

  document.addEventListener(
    "mouseup",
    finishWidgetDrag
  );
};

const beginWidgetResize = (
  mouseDownEvent,
  positionX,
  positionY,
  currentScale,
  dispatch
) => {
  mouseDownEvent.preventDefault();
  mouseDownEvent.stopPropagation();

  activeResize = {
    startMouseX: mouseDownEvent.clientX,
    startScale: currentScale
  };

  const resizeWidget = (moveEvent) => {
    if (!activeResize) return;

    const difference =
      moveEvent.clientX -
      activeResize.startMouseX;

    const nextScale = Math.max(
      0.25,
      Math.min(
        1.4,
        activeResize.startScale +
          difference / 500
      )
    );

    dispatch({
      type: "SET_SCALE",
      scale: nextScale
    });
  };

  const finishResize = (upEvent) => {
    if (!activeResize) return;

    const difference =
      upEvent.clientX -
      activeResize.startMouseX;

    const finalScale = Math.max(
      0.25,
      Math.min(
        1.4,
        activeResize.startScale +
          difference / 500
      )
    );

    dispatch({
      type: "SET_SCALE",
      scale: finalScale
    });

    saveWidgetSettings(
      positionX,
      positionY,
      finalScale
    );

    activeResize = null;

    document.removeEventListener(
      "mousemove",
      resizeWidget
    );

    document.removeEventListener(
      "mouseup",
      finishResize
    );
  };

  document.addEventListener(
    "mousemove",
    resizeWidget
  );

  document.addEventListener(
    "mouseup",
    finishResize
  );
};

export const className = `
top: 0;
left: 0;

.drag-shell {
  position: absolute;
  width: 620px;
  height: 280px;

  transform-origin: top left;

  cursor: grab;
  user-select: none;
  -webkit-user-select: none;
}

.drag-shell:active {
  cursor: grabbing;
}

.drag-shell img {
  -webkit-user-drag: none;
}

.resize-handle {
  position: absolute;
  right: -8px;
  bottom: -8px;

  width: 28px;
  height: 28px;

  cursor: nwse-resize;
  z-index: 20;
}

.resize-handle::after {
  content: "";

  position: absolute;
  right: 6px;
  bottom: 6px;

  width: 10px;
  height: 10px;

  border-right: 3px solid rgba(100, 100, 100, 0.65);
  border-bottom: 3px solid rgba(100, 100, 100, 0.65);
  border-radius: 1px;
}

.ipod {
  width: 620px;
  height: 280px;
  box-sizing: border-box;
  padding: 28px 34px;

  display: flex;
  align-items: center;
  gap: 38px;

  background:
    linear-gradient(
      145deg,
      #f8f8f8 0%,
      #d9d9d9 34%,
      #f3f3f3 65%,
      #bcbcbc 100%
    );

  filter: drop-shadow(
    0 8px 8px rgba(0, 0, 0, 0.16)
  );

  border: 1px solid rgba(255, 255, 255, 0.9);
  border-radius: 54px;

  box-shadow:
    inset 0 2px 7px rgba(255, 255, 255, 0.95),
    inset 0 -4px 10px rgba(0, 0, 0, 0.2),
    0 3px 4px rgba(0, 0, 0, 0.18),
    0 14px 24px rgba(0, 0, 0, 0.34),
    0 28px 46px rgba(0, 0, 0, 0.22);

  font-family:
    -apple-system,
    BlinkMacSystemFont,
    "Helvetica Neue",
    sans-serif;
}

  .screen {
    position: relative;
    width: 330px;
    height: 205px;
    overflow: hidden;

    border: 5px solid #222;
    border-radius: 8px;
    background: #b68f98;
    box-shadow: inset 0 0 7px rgba(0, 0, 0, 0.65);
  }

  .screen-background {
  position: absolute;
  inset: -20px;

  background-size: cover;
  background-position: center;

  filter: blur(20px);
  opacity: 0.58;
  transform: scale(1.18);
}

  .screen-shade {
    position: absolute;
    inset: 0;
    background: linear-gradient(
      90deg,
      rgba(50, 20, 30, 0.12),
      rgba(255, 235, 240, 0.18)
    );
  }

  .screen-content {
    position: relative;
    z-index: 2;

    height: 100%;
    box-sizing: border-box;
    padding: 18px;

    display: grid;
    grid-template-columns: 145px minmax(0, 1fr);
    grid-template-rows: 1fr auto;
    column-gap: 18px;
  }

  .cover {
    width: 145px;
    height: 145px;
    object-fit: cover;
    border-radius: 2px;

    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.35);
  }

  .song-info {
    min-width: 0;
    align-self: center;

    color: white;
    text-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
  }

  .song-title {
    margin: 0 0 4px 0;
    max-width: 100%;

    font-weight: 700;
    line-height: 1;

    overflow-wrap: normal;
    word-break: normal;
    hyphens: auto;
  }

  .artist {
    margin: 0;
    font-size: 14px;
    font-weight: 400;
    opacity: 0.85;
  }

  .progress-section {
    grid-column: 1 / 3;
    min-width: 0;

    display: grid;
    grid-template-columns: auto minmax(0, 1fr) auto;
    align-items: center;
    gap: 7px;

    color: white;
    font-size: 12px;
    font-weight: 600;
  } 

  .progress-track {
    min-width: 0;
    height: 8px;
    overflow: hidden;

    border-radius: 999px;
    background: rgba(255, 255, 255, 0.42);
  }

  .progress-fill {
    width: 64%;
    height: 100%;
    border-radius: inherit;
    background: white;
  }

  .wheel {
    position: relative;

    width: 205px;
    height: 205px;
    flex-shrink: 0;

    border-radius: 50%;
    background: linear-gradient(145deg, #fafafa, #e4e4e4);

    box-shadow:
      inset 0 2px 7px rgba(0, 0, 0, 0.12),
      0 1px 3px rgba(255, 255, 255, 0.8);
  }

  .wheel-center {
    position: absolute;
    top: 50%;
    left: 50%;

    width: 72px;
    height: 72px;

    transform: translate(-50%, -50%);
    border-radius: 50%;

    background: linear-gradient(145deg, #e5e5e5, #f8f8f8);
    box-shadow:
      inset 0 1px 5px rgba(0, 0, 0, 0.18),
      0 1px 2px rgba(255, 255, 255, 0.8);
  }
  .manage-button {
  margin: 0;
  padding: 0;
  border: 0;
  outline: none;

  cursor: pointer;
  z-index: 6;
  -webkit-appearance: none;
}

.manage-button:hover {
  filter: brightness(0.96);
  box-shadow:
    inset 0 1px 6px rgba(0, 0, 0, 0.22),
    0 1px 3px rgba(255, 255, 255, 0.9);
}

.manage-button:active {
  transform:
    translate(-50%, -50%)
    scale(0.94);
}

  .wheel-label {
    position: absolute;
    color: #a0a0a0;
    font-weight: 600;
    user-select: none;
  }

  .menu {
    top: 24px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 17px;
  }

  .previous {
    top: 50%;
    left: 27px;
    transform: translateY(-50%);
    font-size: 23px;
  }

  .next {
    top: 50%;
    right: 27px;
    transform: translateY(-50%);
    font-size: 23px;
  }

  .play {
    bottom: 22px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 21px;
  }

  .wheel-button {
  position: absolute;
  margin: 0;
  padding: 0;
  border: 0;
  outline: none;

  background: transparent;
  color: #a0a0a0;
  font-family: inherit;
  font-weight: 600;
  line-height: 1;

  cursor: pointer;
  user-select: none;
  -webkit-appearance: none;
}

.wheel-button:hover {
  color: #777;
  text-shadow: 0 1px 5px rgba(0, 0, 0, 0.16);
}

.wheel-button:active {
  transform: scale(0.92);
}

.wheel-button.menu {
  top: 24px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 17px;
}

.wheel-button.menu:active {
  transform: translateX(-50%) scale(0.92);
}

.wheel-button.previous {
  top: 50%;
  left: 27px;
  transform: translateY(-50%);
  font-size: 23px;
}

.wheel-button.previous:active {
  transform: translateY(-50%) scale(0.92);
}

.wheel-button.next {
  top: 50%;
  right: 27px;
  transform: translateY(-50%);
  font-size: 23px;
}

.wheel-button.next:active {
  transform: translateY(-50%) scale(0.92);
}

.wheel-button.play {
  bottom: 22px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 21px;
}

.wheel-button.play:active {
  transform: translateX(-50%) scale(0.92);
}

.month-label {
  position: absolute;
  top: 5px;
  right: 8px;

  margin: 0;
  color: rgba(255, 255, 255, 0.68);
  font-size: 8px;
  font-weight: 600;
  letter-spacing: 0.7px;
  text-transform: uppercase;
}

.empty-message {
  width: 100%;
  height: 100%;

  display: flex;
  align-items: center;
  justify-content: center;

  color: #777;
  font-size: 24px;
  font-weight: 600;
  text-align: center;
}
  .empty-screen {
  position: relative;
  width: 330px;
  height: 205px;
  overflow: hidden;

  box-sizing: border-box;
  border: 5px solid #222;
  border-radius: 8px;

  display: flex;
  align-items: center;
  justify-content: center;

  background:
    radial-gradient(
      circle at 30% 20%,
      rgba(255, 255, 255, 0.32),
      transparent 42%
    ),
    linear-gradient(
      145deg,
      #c7a8b0 0%,
      #ad858f 48%,
      #8f6974 100%
    );

  box-shadow: inset 0 0 7px rgba(0, 0, 0, 0.65);
}

.empty-content {
  width: 240px;
  text-align: center;
  color: white;

  text-shadow:
    0 1px 3px rgba(0, 0, 0, 0.28);
}

.empty-note {
  margin-bottom: 8px;

  font-size: 40px;
  font-weight: 500;
  line-height: 1;
}

.empty-title {
  margin: 0 0 7px;

  font-size: 24px;
  font-weight: 700;
  line-height: 1;
}

.empty-instructions {
  margin: 0;

  font-size: 13px;
  font-weight: 500;
  line-height: 1.35;
  opacity: 0.85;
}

.wheel-button.disabled {
  opacity: 0.28;
  cursor: default;
  pointer-events: none;
}

@media (prefers-color-scheme: dark) {
  .ipod {
    position: relative;
    overflow: hidden;

    /*
      Near-black graphite with slight transparency,
      closer to the native widgets beside it.
    */
    background:
  radial-gradient(
    circle at 18% 8%,
    rgba(255,255,255,.08),
    transparent 38%
  ),

  linear-gradient(
    145deg,
    rgba(52,52,56,.97) 0%,
    rgba(39,39,43,.97) 42%,
    rgba(31,31,35,.98) 100%
  );

    -webkit-backdrop-filter:
      blur(18px) saturate(115%);

    backdrop-filter:
      blur(18px) saturate(115%);

    filter: none;

    border:
      1px solid rgba(255, 255, 255, 0.28);

    box-shadow:
      inset 0 1px 0 rgba(255, 255, 255, 0.08),
      inset 0 -1px 0 rgba(0, 0, 0, 0.25),
      0 3px 10px rgba(0, 0, 0, 0.22);
  }

  /*
    Very subtle interior rim like the borders
    around the native Apple widgets.
  */
  .ipod::before {
    content: "";

    box-shadow:
    inset 0 1px 0 rgba(255,255,255,.10),
    inset 0 -1px 0 rgba(0,0,0,.22),
    0 0 0 1px rgba(255,255,255,.05),
    0 4px 10px rgba(0,0,0,.20);

    position: absolute;
    inset: 1px;

    z-index: 1;
    pointer-events: none;

    border-radius: 53px;

    border:
      1px solid rgba(255, 255, 255, 0.08);

    background:
      linear-gradient(
        to bottom,
        rgba(255, 255, 255, 0.055),
        transparent 18%,
        transparent 82%,
        rgba(0, 0, 0, 0.025)
      );
  }

  .screen,
  .wheel {
    position: relative;
    z-index: 2;
  }

  .screen {
    border-width: 3px;
    border-color: rgba(8, 8, 10, 0.78);

    box-shadow:
      inset 0 0 5px rgba(0, 0, 0, 0.43),
      0 0 0 1px rgba(255, 255, 255, 0.035);
  }

  /*
    The wheel is darker than the body,
    but not dramatically blacker.
  */
  .wheel {
    background:
      linear-gradient(
        145deg,
        rgba(36, 36, 40, 0.98) 0%,
        rgba(27, 27, 31, 0.98) 100%
      );

    border:
      1px solid rgba(255, 255, 255, 0.045);

    box-shadow:
      inset 0 1px 1px rgba(255, 255, 255, 0.035),
      inset 0 -1px 2px rgba(0, 0, 0, 0.24),
      0 1px 3px rgba(0, 0, 0, 0.15);
  }

  /*
    Slightly lighter than the wheel,
    like the center button on a real dark iPod.
  */
  .wheel-center {
    background:
      linear-gradient(
        145deg,
        #555559 0%,
        #46464b 100%
      );

    border:
      1px solid rgba(255, 255, 255, 0.04);

    box-shadow:
      inset 0 1px 1px rgba(255, 255, 255, 0.055),
      inset 0 -1px 2px rgba(0, 0, 0, 0.22);
  }

  .manage-button:hover {
    filter: brightness(1.08);

    box-shadow:
      inset 0 1px 2px rgba(255, 255, 255, 0.07),
      inset 0 -1px 2px rgba(0, 0, 0, 0.22);
  }

  .wheel-label,
  .wheel-button {
    color: rgba(245, 245, 247, 0.86);

    text-shadow:
      0 1px 1px rgba(0, 0, 0, 0.22);
  }

  .wheel-button:hover {
    color: #ffffff;

    text-shadow:
      0 0 5px rgba(255, 255, 255, 0.1);
  }

  .resize-handle::after {
    border-right-color:
      rgba(255, 255, 255, 0.35);

    border-bottom-color:
      rgba(255, 255, 255, 0.35);
  }
}

`;
export const render = (
  {
    selectedIndex = songs.length - 1,
    positionX = savedPosition.x,
    positionY = savedPosition.y,
    widgetScale =
  savedPosition.scale !== undefined
    ? savedPosition.scale
    : 0.55
  },
  dispatch
) => {
    if (songs.length === 0) {
  return (
    <div
      className="drag-shell"
      style={{
        left: `${positionX}px`,
        top: `${positionY}px`,
        transform: `scale(${widgetScale})`
      }}
      onMouseDown={(event) =>
        beginWidgetDrag(
          event,
          positionX,
          positionY,
          widgetScale,
          dispatch
        )
      }
    >
      <div className="ipod">
        <div className="empty-screen">
          <div className="empty-content">
            <div className="empty-note">♪</div>

            <h1 className="empty-title">
              No Songs Yet
            </h1>

            <p className="empty-instructions">
              Press ▶Ⅱ to add your first
              <br />
              Song of the Month
            </p>
          </div>
        </div>

        <div className="wheel">
          <button
            className="wheel-button menu disabled"
            disabled
          >
            MENU
          </button>

          <button
            className="wheel-button previous disabled"
            disabled
          >
            ◀
          </button>

          <button
            className="wheel-button next disabled"
            disabled
          >
            ▶
          </button>

          <button
            className="wheel-button play"
            onClick={() =>
              run(
                `/usr/bin/python3 "$HOME/Library/Application Support/Übersicht/widgets/SOTM iPod Widget/src/add_sotm.py"`
              )
            }
            title="Add your first Song of the Month"
          >
            ▶Ⅱ
          </button>

          <div className="wheel-center disabled-center" />
        </div>
      </div>

      <div
        className="resize-handle"
        onMouseDown={(event) =>
          beginWidgetResize(
            event,
            positionX,
            positionY,
            widgetScale,
            dispatch
          )
        }
        title="Drag to resize"
      />
    </div>
  );
}

  const safeIndex =
    selectedIndex >= 0 && selectedIndex < songs.length
      ? selectedIndex
      : songs.length - 1;

  const song = songs[safeIndex];

  return (
    <div
      className="drag-shell"
      style={{
      left: `${positionX}px`,
      top: `${positionY}px`,
      transform: `scale(${widgetScale})`
    }}
    onMouseDown={(event) =>
      beginWidgetDrag(
        event,
        positionX,
        positionY,
        widgetScale,
        dispatch
      )
    }
  >
    <div className="ipod">
      <div className="screen">
        <div
          className="screen-background"
          style={{
            backgroundImage: `url("${song.cover}")`
          }}
        />

        <div className="screen-shade" />

        <div className="screen-content">
          <p className="month-label">{song.month}</p>

          <img
            className="cover"
            src={song.cover}
            alt={`${song.title} album cover`}
          />

          <div className="song-info">
            <h1
              lang="en"
              className="song-title"
              style={{
                fontSize:
                  song.title.length > 14
                    ? "19px"
                    : song.title.length > 10
                      ? "22px"
                      : "27px"
              }}
            >
              {song.title}
            </h1>
            <p className="artist">{song.artist}</p>
          </div>

          <div className="progress-section">
            <span>{song.currentTime}</span>

            <div className="progress-track">
              <div
                className="progress-fill"
                style={{ width: `${song.progress}%` }}
              />
            </div>

            <span>{song.duration}</span>
          </div>
        </div>
      </div>

      <div className="wheel">
        <button
          className="wheel-button menu"
          onClick={() => openUrl(song.playlistUrl)}
          title="Open Songs of the Month playlist"
        >
          MENU
        </button>

        <button
          className="wheel-button previous"
          onClick={() =>
            dispatch({ type: "PREVIOUS_MONTH" })
          }
          title="Previous month"
        >
          ◀
        </button>

        <button
          className="wheel-button next"
          onClick={() =>
            dispatch({ type: "NEXT_MONTH" })
          }
          title="Next month"
        >
          ▶
        </button>

        <button
  className="wheel-button play"
  onClick={() =>
    run(
      `/usr/bin/python3 "$HOME/Library/Application Support/Übersicht/widgets/SOTM iPod Widget/src/add_sotm.py"`
    )
  }
  title="Add a Song of the Month"
>
  ▶Ⅱ
</button>

        <button
  className="wheel-center manage-button"
  onClick={() =>
    run(
      `/usr/bin/python3 "$HOME/Library/Application Support/Übersicht/widgets/SOTM iPod Widget/src/manage_sotm.py" ${safeIndex}`
    )
  }
  title="Edit or delete this entry"
/>
      </div>
    </div>

     <div
      className="resize-handle"
      onMouseDown={(event) =>
        beginWidgetResize(
          event,
          positionX,
          positionY,
          widgetScale,
          dispatch
        )
      }
      title="Drag to resize"
    />
  </div>
);
};